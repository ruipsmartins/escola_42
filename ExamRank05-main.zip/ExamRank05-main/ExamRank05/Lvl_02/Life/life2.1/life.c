#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define ALIVE '0'
#define DEAD ' '

int width, height;

char get_cell(char *curr, int x, int y) {
    if (x < 0 || y < 0 || x >= width || y >= height)
        return DEAD;
    return curr[y * width + x];
}

int count_neighbours(char *board, int x, int y) {
    int dx, dy, count = 0;
    for (dy = -1; dy <= 1; dy++) {
        for (dx = -1; dx <= 1; dx++) {
            if (dx == 0 && dy == 0)
                continue;
            if (get_cell(board, x + dx, y + dy) == ALIVE)
                count++;
        }
    }
    return count;
}

void update(char *curr, char *next) {
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int n = count_neighbours(curr, x, y);
            char c = get_cell(curr, x, y);
            if (c == ALIVE && (n == 2 || n == 3))
                next[y * width + x] = ALIVE;
            else if (c == DEAD && n == 3)
                next[y * width + x] = ALIVE;
            else
                next[y * width + x] = DEAD;
        }
    }
}

void print_board(char *board) {
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++)
            putchar(get_cell(board, x, y));
        putchar('\n');
    }
}

int main(int argc, char **argv) {
    if (argc != 4)
        return 1;
    width = atoi(argv[1]);
    height = atoi(argv[2]);
    int iterations = atoi(argv[3]);
    char *board = malloc(width * height);
    char *temp = malloc(width * height);

    for (int i = 0; i < width * height; i++) {
        board[i] = ' ';
        temp[i] = ' ';
    }
    //Draw with pen
    int x = 0, y = 0, pen = 0;
    char c;
    while (read(0, &c, 1) > 0) {
        if (c == 'w' && y > 0)
            y--;
        else if (c == 's' && y < height - 1)
            y++;
        else if (c == 'a' && x > 0)
            x--;
        else if (c == 'd' && x < width - 1)
            x++;
        else if (c == 'x')
            pen = !pen;
        if (pen)
            board[y * width + x] = ALIVE;
    }
    for (int i = 0; i < iterations; i++) {
        update(board, temp);
        char *swap = board;
        board = temp;
        temp = swap;
    }
    print_board(board);
    free(board);
    free(temp);
    return 0;
}