#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

#define ALIVE '0'
#define DEAD ' '

int width, height;

// Safely get cell state (returns 0 if out of bounds)
char get_cell(char *grid, int x, int y) {
	if (x < 0 || y < 0 || x >= width || y >= height)
		return DEAD;
	return grid[y * width + x];
}

// Count live neighbors of a cell
int count_neighbors(char *grid, int x, int y) {
	int dx, dy, count = 0;
	for (dy = -1; dy <= 1; dy++) {
		for (dx = -1; dx <= 1; dx++) {
			if (dx == 0 && dy == 0)
                continue;
			if (get_cell(grid, x + dx, y + dy) == ALIVE)
				count++;
		}
	}
	return count;
}

// Apply one tick of Game of Life
void update(char *curr, char *next) {
	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
			int n = count_neighbors(curr, x, y);
			char c = get_cell(curr, x, y);
			if (c == ALIVE && (n == 2 || n == 3))
				next[y * width + x] = ALIVE;
			else if (c == DEAD && n == 3)
				next[y * width + x] = ALIVE;
			else
				next[y * width + x] = DEAD;
		}
	}
}

// Print the board to stdout
void print_board(char *grid) {
	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++)
			putchar(get_cell(grid, x, y));
		putchar('\n');
	}
}

int main(int argc, char **argv) {
	if (argc != 4)
		return 1;
	width = atoi(argv[1]);
	height = atoi(argv[2]);
	int iterations = atoi(argv[3]);
	char *board = malloc(width * height);
    char *temp = malloc(width * height);

    for (int i = 0; i < width * height; i++) {
	    board[i] = ' ';
	    temp[i] = ' ';
    }
	// Draw with pen
	int x = 0, y = 0, pen = 0;
	char c;
	while (read(0, &c, 1) > 0) {
		if (c == 'w' && y > 0)
            y--;
		else if (c == 's' && y < height - 1)
            y++;
		else if (c == 'a' && x > 0)
            x--;
		else if (c == 'd' && x < width - 1)
            x++;
		else if (c == 'x')
            pen = !pen;
		if (pen)
			board[y * width + x] = ALIVE;
	}
	// Run iterations
	for (int i = 0; i < iterations; i++) {
		update(board, temp);
		char *swap = board;
		board = temp;
		temp = swap;
	}
	// Print final state
	print_board(board);
	free(board);
	free(temp);
	return 0;
}
