#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

#define MAX 1024

char map[MAX][MAX];
int rows, cols;
char empty, full, obstacle;

int is_square(int c, int r, int size) {
    if (r + size > rows || c + size > cols)
        return 0;
    for (int i = r; i < r + size; i++) {
        for (int j = c; j < c + size; j++) {
            if (map[i][j] != empty)
                return 0;
        }
    }
    return 1;
}

void fill_square(int r, int c, int size) {
    for (int i = r; i < r + size; i++)
        for (int j = c; j < c + size; j++)
            map[i][j] = full;
}

int main(int argc, char **argv) {
    if (argc != 2)
        return 1;
    FILE *f = fopen(argv[1], "r");
    if (!f)
        return 1;
    fscanf(f, "%d %c %c %c\n", &rows, &empty, &obstacle, &full);
    if (rows <= 0 || rows > MAX || empty == full || empty == obstacle || obstacle == full) {
        fclose(f);
        return 1;
    }
    for (int i = 0; i < rows; i++) {
        fgets(map[i], MAX, f);
        cols = strlen(map[i]);
        if (map[i][cols - 1] == '\n')
            map[i][--cols] = '\0';
    }
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (map[i][j] != empty && map[i][j] != obstacle) {
                fclose(f);
                fprintf(stderr, "Invalid character in map: %c\n", map[i][j]);
                return 1;
            }
        }
    }
    int best_size = 0, best_r = 0, best_c = 0;
    for (int r = 0; r < rows; r++) {
        for (int c = 0; c < cols; c++) {
            for (int s = 1; is_square(c, r, s); s++) {
                if (s > best_size) {
                    best_size = s;
                    best_r = r;
                    best_c = c;
                }
            }
        }
    }
    fill_square(best_r, best_c, best_size);
    for (int i = 0; i < rows; i++)
        printf("%s\n", map[i]);
    return 0;
}