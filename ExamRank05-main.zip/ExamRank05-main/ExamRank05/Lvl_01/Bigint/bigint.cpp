#include "bigint.hpp"

//Constructors and destructors
bigint::bigint() : value("0") {}

bigint::bigint(const std::string str) {
    if (str.empty() || str.find_first_not_of("0123456789") != std::string::npos)
        value = "0";
    else
        value = str;
    removeLeadingZeros();
}

bigint::bigint(unsigned int n) {
    if (n == 0) {
        value = "0";
        return;
    }
    value = "";
    while (n > 0) {
        char digit = (n % 10) + '0';
        value.insert(value.begin(), digit);
        n /= 10;
    }
}

bigint::bigint(const bigint &other) {
    this->value = other.value;
}

bigint &bigint::operator=(const bigint &other) {
    if (this != &other) {
        this->value = other.value;
    }
    return *this;
}

bigint::~bigint() {}

//Methods
void bigint::removeLeadingZeros() {
    size_t i = 0;
    while (i < value.length() - 1 && value[i] == '0')
        ++i;
    value = value.substr(i);
}

//Arithmetic
bigint bigint::operator+(const bigint &other) const {
    std::string res = "";
    int carry = 0;

    int i = value.length() - 1;
    int j = other.value.length() - 1;

    while (i >= 0 || j >= 0 || carry) {
        int a = i >= 0 ? value[i--] - '0' : 0;
        int b = j >= 0 ? other.value[j--] - '0' : 0;
        int sum = a + b + carry;

        carry = sum / 10;
        res.insert(res.begin(), (sum % 10) + '0');
    }
    return bigint(res);
}

bigint &bigint::operator+=(const bigint &other) {
    *this = *this + other;
    return *this;
}

bigint bigint::operator-(const bigint &other) {
    (void)other;
    return bigint();
}

bigint bigint::operator++(int) {
    bigint temp(*this);
    ++(*this);
    return temp;
}

bigint &bigint::operator++() {
    *this += bigint(1);
    return *this;
}

bigint bigint::operator<<(unsigned int shift) const {
    if (*this == bigint(0))
        return *this;
    std::string result = value + std::string(shift, '0');
    return bigint(result);
}

bigint bigint::operator>>(unsigned int shift) const {
    if (shift >= value.length())
        return bigint(0);
    return bigint(value.substr(0, value.length() - shift));
}

bigint &bigint::operator<<=(unsigned int shift) {
    *this = *this << shift;
    return *this;
}

bigint &bigint::operator>>=(unsigned int shift) {
    *this = *this >> shift;
    return *this;
}

bool bigint::operator==(const bigint &other) const {
    return this->value == other.value;
}

bool bigint::operator!=(const bigint &other) const {
    return this->value != other.value;
}

bool bigint::operator<(const bigint &other) const {
    if (this->value.length() != other.value.length())
        return this->value.length() < other.value.length();
    return this->value < other.value;
}

bool bigint::operator<=(const bigint &other) const {
    return *this < other || *this == other;
}

bool bigint::operator>(const bigint &other) const {
    if (this->value.length() != other.value.length())
        return this->value.length() > other.value.length();
    return this->value > other.value;
}

bool bigint::operator>=(const bigint &other) const {
    return *this > other || *this == other;
}

std::ostream &operator<<(std::ostream &os, const bigint &other) {
    os << other.value;
    return os;
}