#include "bigint.hpp"
#include <iostream>

int main()
{
    const bigint a(42);
    bigint b(1), c, d(1337), e(d), g("123456787654323456787543234567623456787654323456765432234321234532");

    std::cout << "a = " << a << std::endl;
    std::cout << "b = " << b << std::endl;
    std::cout << "c = " << c << std::endl;
    std::cout << "d = " << d << std::endl;
    std::cout << "e = " << e << std::endl;
    std::cout << "g = " << g << std::endl;
    std::cout << "g + b = " << g + b << std::endl;
    std::cout << "a + b = " << a + b << std::endl;
    std::cout << "(c+= a) = " << (c += a) << std::endl;
    std::cout << "c - a = " << c - a << std::endl;
    std::cout << "b = " << b << std::endl;
    std::cout << "++b = " << ++b << std::endl;
    std::cout << "b++ = " << b++ << std::endl;
    std::cout << "(b << 10) + 42 = " <<  (b << 10) + 42 << std::endl;
    std::cout << "(g >> 2) = " <<  (g >> 2) << std::endl;
    std::cout << "(d <<= 4) = " << (d <<= 4) << std::endl;
    std::cout << "(d >>= 2) = " << (d >>= 2) << std::endl;
    std::cout << "a = " << a << std::endl;
    std::cout << "d = " << d << std::endl;
    bigint f("42");
    std::cout << "(f << 2) = " <<  (f << 2) << std::endl;
    std::cout << "(f >> 2) = " << (f >> 2) << std::endl;
    std::cout << "f = " << f << std::endl;
    std::cout << "a == f = " << (a == f) << std::endl;
    std::cout << "a <= f = " << (a <= f) << std::endl;
    std::cout << "a >= f = " << (a >= f) << std::endl;
    std::cout << "a < f = " << (a < f) << std::endl;
    std::cout << "a > f = " << (a > f) << std::endl;
    std::cout << "(d < a) = " << (d < a) << std::endl;
    std::cout << "(d > a) = " << (d > a) << std::endl;
    std::cout << "(d == a) = " << (d == a) << std::endl;
    std::cout << "(d != a) = " << (d != a) << std::endl;
    std::cout << "(d <= a) = " << (d <= a) << std::endl;
    std::cout << "(d >= a) = " << (d >= a) << std::endl;
}