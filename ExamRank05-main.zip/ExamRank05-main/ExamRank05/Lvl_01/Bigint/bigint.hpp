#ifndef BIGINT_HPP
#define BIGINT_HPP

#include <iostream>
#include <string>
#include <algorithm>

class bigint {
    public:
        bigint();
        bigint(const std::string str);
        bigint(unsigned int n);
        bigint(const bigint &other);
        bigint &operator=(const bigint &other);
        ~bigint();

        bigint operator+(const bigint &other) const;
        bigint &operator+=(const bigint &other);
        bigint operator-(const bigint &other);

        bigint &operator++();
        bigint operator++(int);

        //Bit shift
        bigint operator>>(unsigned int shift) const;
        bigint operator<<(unsigned int shift) const;
        bigint &operator>>=(unsigned int shift);
        bigint &operator<<=(unsigned int shift);

        //Comparrison
        bool operator==(const bigint &other) const;
        bool operator!=(const bigint &other) const;
        bool operator<(const bigint &other) const;
        bool operator<=(const bigint &other) const;
        bool operator>(const bigint &other) const;
        bool operator>=(const bigint &other) const;

        friend std::ostream &operator<<(std::ostream &os, const bigint &other);

    private:
        std::string value;
        void removeLeadingZeros();

};


#endif