#ifndef BIGINT_HPP
#define BIGINT_HPP

#include <string>
#include <iostream>
#include <algorithm>

class bigint {
    private:
        std::string value;

        void removeLeadingZeros() {
            int i = 0;
            while (i < value.length() - 1 && value[i] == '0')
                ++i;
            value = value.substr(i);
        }

    public:
        bigint() {
            value = "0";
        }

        bigint(int n) {
            if (n == 0) {
                value = "0";
                return;
            }
            value = "";
            while (n > 0) {
                char digit = (n % 10) + '0';
                value.insert(value.begin(), digit);
                n /= 10;
            }
        }

        bigint(std::string str) {
            if (str.empty() || str.find_first_not_of("0123456789") != std::string::npos)
                value = "0";
            else
                value = str;
            removeLeadingZeros();
        }

        bigint(const bigint &other) {
            this->value = other.value;
        }

        bigint &operator=(const bigint &other) {
            if (this != &other)
                this->value = other.value;
            return *this;
        }

        ~bigint() {}

        bigint operator+(const bigint &other) const {
            std::string res = "";
            int carry = 0;

            int i = this->value.length() - 1;
            int j = other.value.length() - 1;

            while (i >= 0 || j >= 0 || carry) {
                int a = i >= 0 ? this->value[i--] - '0' : 0;
                int b = j >= 0 ? other.value[j--] - '0' : 0;
                int sum = a + b + carry;

                carry = sum / 10;
                res.insert(res.begin(), (sum % 10) + '0');
            }
            return bigint(res);
        }

        bigint &operator+=(const bigint &other) {
            *this = *this + other;
            return *this;
        }

        bigint operator-(const bigint &other) const {
            if (value.length() != other.value.length() && value.length() < other.value.length())
                return bigint();
            return bigint();
        }
        bigint operator<<(int shift) const {
            if (value == "0")
                return bigint();
            std::string res = value + std::string(shift, '0');
            return bigint(res);

        }
        bigint &operator<<=(int shift) {
            *this = *this << shift;
            return *this;
        }

        bigint operator>>(int shift) const {
            if (shift >= value.length())
                return bigint();
            return bigint(value.substr(0, value.length() - shift));
        }

        bigint &operator>>=(int shift) {
            *this = *this >> shift;
            return *this;
        }

        bigint &operator++() {
            *this += bigint(1);
            return *this;
        }

        bigint operator++(int) {
            bigint temp(*this);
            ++(*this);
            return temp;
        }

        bool operator==(const bigint &other) const {
            return this->value == other.value;
        }

        bool operator!=(const bigint &other) const {
            return this->value != other.value;
        }

        bool operator<(const bigint &other) const {
            if (value.length() != other.value.length())
                return value.length() < other.value.length();
            return value < other.value;
        }

        bool operator<=(const bigint &other) const {
            return *this < other || *this == other;
        }

        bool operator>(const bigint &other) const {
            if (value.length() != other.value.length())
                return value.length() > other.value.length();
            return value > other.value;
        }

        bool operator>=(const bigint &other) const {
            return *this > other || *this == other;
        }

        friend std::ostream &operator<<(std::ostream &os, const bigint &src) {
            os << src.value;
            return os;
        }
};      

#endif