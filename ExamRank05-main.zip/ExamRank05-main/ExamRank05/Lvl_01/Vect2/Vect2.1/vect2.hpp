#ifndef VECT2_HPP
#define VECT2_HPP

#include <string>
#include <iostream>
#include <array>

class vect2 {
    public:
        vect2() : vec{0, 0} {}
        vect2(int _x, int _y) : vec{_x, _y} {}
        vect2(const vect2 &other) : vec{other.vec[0], other.vec[1]} {}
        vect2 &operator=(const vect2 &other) {
            if (this != &other) {
                this->vec[0] = other.vec[0];
                this->vec[1] = other.vec[1];
            }
            return *this;
        }
        ~vect2() {}

        vect2 operator+(const vect2 &other) const {
            return vect2(vec[0] + other.vec[0], vec[1] + other.vec[1]);
        }
        vect2 operator-(const vect2 &other) const {
            return vect2(vec[0] - other.vec[0], vec[1] - other.vec[1]);
        }
        vect2 operator*(int scalar) const {
            return vect2(vec[0] * scalar, vec[1] * scalar);
        }
        
        vect2 &operator+=(const vect2 &other) {
            vec[0] = vec[0] + other.vec[0];
            vec[1] = vec[1] + other.vec[1];
            return *this;
        }
        vect2 &operator-=(const vect2 &other) {
            vec[0] = vec[0] - other.vec[0];
            vec[1] = vec[1] - other.vec[1];
            return *this;
        }
        vect2 &operator*=(int scalar) {
            vec[0] = vec[0] * scalar;
            vec[1] = vec[1] * scalar;
            return *this;
        }

        int operator[](unsigned int index) const {
            if (index == 0)
                return vec[0];
            else
                return vec[1];
        }
        int &operator[](unsigned int index) {
            if (index == 0)
                return vec[0];
            else
                return vec[1];
        }

        bool operator==(const vect2 &other) const {
            return (vec[0] == other.vec[0] && vec[1] == other.vec[1]);
        }

        bool operator!=(const vect2 &other) const {
            return (vec[0] != other.vec[0] || vec[1] != other.vec[1]);
        }

        vect2 &operator++() {
            ++vec[0];
            ++vec[1];
            return *this;
        }
        vect2 operator++(int) {
            vect2 temp = *this;
            ++vec[0];
            ++vec[1];
            return temp;
        }
        vect2 &operator--() {
            --vec[0];
            --vec[1];
            return *this;
        }
        vect2 operator--(int) {
            vect2 temp = *this;
            --vec[0];
            --vec[1];
            return temp;
        }

        vect2 &operator-() {
            vec[0] = -vec[0];
            vec[1] = -vec[1];
            return *this;
        }

        friend vect2 operator*(int scalar, const vect2 &other) {
            return vect2(scalar * other.vec[0], scalar * other.vec[1]);
        }

        friend std::ostream &operator<<(std::ostream &os, const vect2 &src) {
            os << "{" << src.vec[0] << ", " << src.vec[1] << "}" << std::endl;
            return os;
        }

        std::array<int, 2> vec;
};

#endif