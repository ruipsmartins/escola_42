#ifndef VECT2_HPP
#define VECT2_HPP

#include <array>
#include <iostream>
#include <string>
#include <stdexcept>

class vect2 {
    private:
    public:
        std::array<int, 2> _vector;
        vect2();
        vect2(int _x, int _y);
        vect2(const vect2& other);
        vect2 &operator=(const vect2& other);
        ~vect2();

        vect2 operator+(const vect2 &other) const;
        vect2 operator-(const vect2 &other) const;
        vect2 operator*(int scalar) const;
        vect2 operator/(int scalar) const;

        bool operator==(const vect2 &other) const;
        bool operator!=(const vect2 &other) const;

        vect2 &operator+=(const vect2 &other);
        vect2 &operator-=(const vect2 &other);
        vect2 &operator*=(int scalar);
        vect2 &operator/=(int scalar);

        int operator[](int index) const;
        int &operator[](int index);

        vect2 operator++(int);
        vect2 &operator++();
        vect2 operator--(int);
        vect2 &operator--();

        vect2 operator-() const;
        vect2 &operator-();
        
};

vect2 operator*(int scalar, const vect2 &v);
std::ostream &operator<<(std::ostream &os, const vect2 &v);


#endif