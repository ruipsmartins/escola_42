#include "vect2.hpp"

vect2::vect2() : _vector{0, 0} {}

vect2::vect2(int _x, int _y) : _vector{_x, _y} {}

vect2::vect2(const vect2& other) : _vector(other._vector) {}

vect2& vect2::operator=(const vect2& other) {
    if (this != &other) {
        _vector = other._vector;
    }
    return *this;
}

vect2::~vect2() {}

vect2 vect2::operator+(const vect2 &other) const{
    return vect2(_vector[0] + other._vector[0], _vector[1] + other._vector[1]);
}

vect2 vect2::operator-(const vect2 &other) const{
    return vect2(_vector[0] - other._vector[0], _vector[1] - other._vector[1]);
}

vect2 vect2::operator*(int scalar) const{
    return vect2(_vector[0] * scalar, _vector[1] * scalar);
}

vect2 vect2::operator/(int scalar) const{
    if (scalar == 0) {
        throw std::invalid_argument("Division by zero is not allowed.");
    }
    return vect2(_vector[0] / scalar, _vector[1] / scalar);
}

bool vect2::operator==(const vect2 &other) const{
    return _vector[0] == other._vector[0] && _vector[1] == other._vector[1];
}

bool vect2::operator!=(const vect2 &other) const{
    return !(*this == other);
}

vect2 &vect2::operator+=(const vect2 &other) {
    _vector[0] += other._vector[0];
    _vector[1] += other._vector[1];
    return *this;
}

vect2 &vect2::operator-=(const vect2 &other) {
    _vector[0] -= other._vector[0];
    _vector[1] -= other._vector[1];
    return *this;
}

vect2 &vect2::operator*=(int scalar) {
    _vector[0] *= scalar;
    _vector[1] *= scalar;
    return *this;
}

vect2 &vect2::operator/=(int scalar) {
    if (scalar == 0) {
        throw std::invalid_argument("Division by zero is not allowed.");
    }
    _vector[0] /= scalar;
    _vector[1] /= scalar;
    return *this;
}

int vect2::operator[](int index) const{
    if (index == 0)
        return _vector[0];
    else
        return _vector[1];
}

int &vect2::operator[](int index) {
    if (index == 0)
        return _vector[0];
    else if (index == 1)
        return _vector[1];
    throw std::out_of_range("Index out of range. Use 0 or 1.");
}

vect2 vect2::operator-() const {
    return vect2(-_vector[0], -_vector[1]);
}

vect2 &vect2::operator-() {
    _vector[0] = -_vector[0];
    _vector[1] = -_vector[1];
    return *this;
}

vect2 vect2::operator++(int) {
    vect2 temp = *this;
    ++_vector[0];
    ++_vector[1];
    return temp;
}

vect2 &vect2::operator++() {
    ++_vector[0];
    ++_vector[1];
    return *this;
}

vect2 vect2::operator--(int) {
    vect2 temp = *this;
    --_vector[0];
    --_vector[1];
    return temp;
}

vect2 &vect2::operator--() {
    --_vector[0];
    --_vector[1];
    return *this;
}

vect2 operator*(int scalar, const vect2 &v) {
    return v * scalar;
}

std::ostream& operator<<(std::ostream &os, const vect2 &v) {
    os << "{" << v._vector[0] << ", " << v._vector[1] << "}";
    return os;
}
